from django.apps import AppConfig


class PlayersfansappConfig(AppConfig):
    name = 'playersFansApp'
