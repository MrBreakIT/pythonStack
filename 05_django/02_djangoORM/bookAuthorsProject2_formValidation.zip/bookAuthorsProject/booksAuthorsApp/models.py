from django.db import models


class BookManager(models.Manager):
    def bookValidator(self, postData):
        validationErrors = {}
        if len(postData ["title"]) == 0:
            validationErrors["title"] = "Please enter a Book Title"
        if len(postData["desc"]) < 5:
            validationErrors["desc"] = "Please enter the Books Description longer than 5 characters"
        return validationErrors

            
class AuthorManager(models.Manager):
    def authorValidator(self, postData):
        validationErrors = {}
        if len(postData ["fname"]) == 0:
            validationErrors["fname"] = "Please enter Authors first name"
        if len(postData ["lname"]) == 0:
            validationErrors["lname"] = "Please enter a Authors last name"
        if len(postData["notes"]) < 5:
            validationErrors["notes"] = "Please enter a short note about the Author"
        return validationErrors

# Create your models here.
class Book (models.Model):
    # id - is implicit when creating models
    title = models.CharField(max_length=45)
    desc = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = BookManager()      #this is addition from class BookManager
    def __str__(self):
        return f"book_object{self.title}\n"

class Author (models.Model):
    # id - is implicit when creating models        
    books = models.ManyToManyField(
        Book, related_name="authors")
    fname = models.CharField(max_length=45)
    lname = models.CharField(max_length=45)
    notes = models.TextField("")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = AuthorManager()      #this is addition from class AuthorManager
    def __str__(self):
        return f"{self.fname} {self.lname}, {self.books}\n"