from django.urls import path
from . import views


urlpatterns = [
    #***********************************
    #           Landing Page
    path('', views.index),
    path("logIn", views.logIn),
    

    #***********************************
    #           Books
    #    
    path("booksHomepage", views.booksHomepage),
    path("createBook", views.createBook),
    path("books/<int:titleID>", views.showTitle),
    path("addAuthor/<int:bookinfo>", views.addAuthor),
    path("delete/<int:titleID>", views.deleteBook),
    path("edit/<int:titleID>", views.editBook),
    path("updateBook/<int:titleID>", views.updateBook),
    #************************************
    #           Authors
    #
    path("authorsHomepage", views.authorsHomepage),
    path("createAuthor", views.createAuthor),
    path("author/<int:authorID>", views.showAuthor),
    path("addBookToAuthor/<int:authorID>", views.addBookToAuthor),
    path("deleteAuthor/<int:authorID>", views.deleteAuthor),
    path("editAuthor/<int:authorID>", views.editAuthorpage),
    path("updateAuthor/<int:authorID>", views.updateAuthor),
]











