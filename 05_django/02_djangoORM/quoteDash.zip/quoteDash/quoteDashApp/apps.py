from django.apps import AppConfig


class QuotedashappConfig(AppConfig):
    name = 'quoteDashApp'
