from django.apps import AppConfig


class DojoNinjasAppConfig(AppConfig):
    name = 'dojoNinjas_App'
